import bcrypt
import jwt
from datetime import datetime, timedelta

SECRET_KEY = 'your-secret-key'

def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

def check_password(password, hashed):
    return bcrypt.checkpw(password.encode('utf-8'), hashed)

def generate_token(username):
    payload = {'username': username, 'exp': datetime.utcnow() + timedelta(hours=2)}
    return jwt.encode(payload, SECRET_KEY, algorithm='HS256')