from flask import Flask, request, jsonify
from flask_cors import CORS
from models import db, Order, Admin
from utils import hash_password, check_password, generate_token

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

with app.app_context():
    db.create_all()

@app.route('/register-admin', methods=['POST'])
def register_admin():
    data = request.json
    if Admin.query.filter_by(username=data['username']).first():
        return jsonify({'error': 'Username already exists'}), 400
    admin = Admin(username=data['username'], password_hash=hash_password(data['password']))
    db.session.add(admin)
    db.session.commit()
    return jsonify({'message': 'Admin created'})

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    user = Admin.query.filter_by(username=data['username']).first()
    if user and check_password(data['password'], user.password_hash):
        token = generate_token(user.username)
        return jsonify({'token': token})
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/submit-order', methods=['POST'])
def submit_order():
    data = request.json
    order = Order(name=data['name'], order_id=data['order_id'], details=data['details'])
    db.session.add(order)
    db.session.commit()
    return jsonify({'message': 'Order saved'})

@app.route('/orders', methods=['GET'])
def get_orders():
    orders = Order.query.all()
    return jsonify([
        {'name': o.name, 'order_id': o.order_id, 'details': o.details}
        for o in orders
    ])

if __name__ == '__main__':
    app.run(debug=True)